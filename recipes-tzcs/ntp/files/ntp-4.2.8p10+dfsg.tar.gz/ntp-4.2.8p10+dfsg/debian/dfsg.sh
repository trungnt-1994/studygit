#!/bin/sh
# Used to create the dfsg .orig.tar from the upstream source
rm html/hints/solaris-dosynctodr.html
rm libntp/adjtime.c
rm include/adjtime.h
rm include/timepps-SCO.h
rm include/timepps-Solaris.h
rm include/timepps-SunOS.h
rm ports/winnt/libntp/messages.mc
rm ports/winnt/include/hopf_PCI_io.h
rm scripts/monitoring/lr.pl
rm scripts/monitoring/ntp.pl
rm scripts/monitoring/ntploopstat
rm scripts/monitoring/ntploopwatch
rm scripts/monitoring/ntptrap
rm scripts/ntpver.in
rm libparse/clk_wharton.c
