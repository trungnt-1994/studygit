#include <stdio.h>
#include <time.h>
#include <string.h>

#include <linux/ioctl.h>
#include <sys/ioctl.h>
#include <linux/input.h>
#include <fcntl.h>

#include <sys/io.h>
#include <tzcslib/TzcsUtil.h>
//#include "tvalzctl.h"

//SetPonTime
//argv[1]: Option: Power On Latency (minute)(ex. 3)(DEC string)

int fd;
ghci_interface ghci_buf;

int SCIHCI()
{
//  struct RegSet tmpRP;
//  int ah;

/*
  ah = (ghci_buf.ghci_eax % 0x10000) >> 8;
  //printf("AH=%d\n", ah); 

  switch(ah){
    case 0xF1:
      //SCI Open
      printf("SCI Open\n");
      break;
    case 0xF2:
      //SCI Close
      printf("SCI Close\n");
      break;
    case 0xF3:
      //SCI Read
      printf("SCI Read\n");
      break;
    case 0xF4:
      //SCI Write
      printf("SCI Write\n");
      break;
    case 0xFE:
      //HCI Read
      printf("HCI Read\n");
      ghci_buf.ghci_edx = count;
      break;
    case 0xFF:
      //HCI Write
      printf("HCI Write\n");
      count = ghci_buf.ghci_edx;
      break;
    default:
      //Default
      printf("unknown\n");
      break;
  }
*/

  ioctl(fd, IOCTL_TVALZ_GHCI, &ghci_buf);
}

int main(int args, char *argv[])
{
  char *endp;
  int CReset;
  int Latency;
/*
  int tmpm, tmph;
  int PonTime;
  time_t now;
  struct tm *pnow;
  char bit[16];
  unsigned char sec;
  unsigned char min;
  unsigned char hour;
  unsigned char a_sec;
  unsigned char a_min;
  unsigned char a_hour;
  unsigned char a_7e;
*/
  char time_info[STR_BUF_SIZE];
  char command[STR_BUF_SIZE*4];

  CReset = 0;
  if(args > 1){
    if((strcmp(argv[1], "-R")==0) || (strcmp(argv[1], "-r")==0)){
      CReset = 1;
    }
    Latency = strtol(argv[1], &endp, 10);
  }else{
    Latency = 1;
  }
  Latency++;

  fd = open("/dev/tvalz0", O_RDONLY);

  if(CReset == 1){
    //Count reset
    ghci_buf.ghci_eax = 0x0000FF00;
    ghci_buf.ghci_ebx = 0x000000D0;
    ghci_buf.ghci_ecx = 0x0000000D;
    ghci_buf.ghci_edx = 0x00000000;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    SCIHCI();
  }else{
    //Read Count
    ghci_buf.ghci_eax = 0x0000FE00;
    ghci_buf.ghci_ebx = 0x000000D0;
    ghci_buf.ghci_ecx = 0x0000000D;
    ghci_buf.ghci_edx = 0x00000000;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    SCIHCI();
    ghci_buf.ghci_edx = ghci_buf.ghci_ecx;
    ghci_buf.ghci_edx++;
    //Write Count
    ghci_buf.ghci_eax = 0x0000FF00;
    ghci_buf.ghci_ebx = 0x000000D0;
    ghci_buf.ghci_ecx = 0x0000000D;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    printf("%d\n", ghci_buf.ghci_edx);
    SCIHCI();

//    system("date");
//    system("date -u");

    system("echo 0 > /sys/class/rtc/rtc0/wakealarm");
    memset(time_info, '\0', sizeof(time_info));
    get_info("date \"+%Y-%m-%d %H:%M:%S\" -D '%s' -d \"$((`date +%s`+2*60))\"", time_info);
    printf("%s", time_info);
    time_info[strlen(time_info) - 1] = '\0';
    memset(command, '\0', sizeof(command));
    sprintf(command, "date -u --date \"%s\" +\%%s > /sys/class/rtc/rtc0/wakealarm", time_info);
    system(command);

//    system("cat /proc/driver/rtc");

//    system("sleep 60");

/*
    now = time(NULL);
    //printf("%d\n", now);
    //printf("%s\n", ctime(&now));
// -del 09/08 tanaka
//    pnow = localtime(&now);
// -end 09/08 tanaka
// -Add 09/08 tanaka
// -del 02/12 tanaka
//    pnow = gmtime(&now);
// -end 02/12 tanaka
// -End 09/08 tanaka
// -del 02/12 tanaka
    pnow = localtime(&now);
// -end 02/12 tanaka
    printf("%d-%d-%d %d:%d:%d\n", pnow->tm_year, pnow->tm_mon, pnow->tm_mday, pnow->tm_hour, pnow->tm_min, pnow->tm_sec);

    iopl(3);
    asm("cli");
  
    // now time get
    outb_p(0,0x70); 
    sec = inb_p(0x71);
    outb_p(2,0x70); 
    min = inb_p(0x71);
    outb_p(4,0x70); 
    hour = inb_p(0x71);
 
    // alarm clear
    outb_p(1,0x70); 
    outb_p(0,0x71);
    outb_p(3,0x70); 
    outb_p(0,0x71);
    outb_p(5,0x70); 
    outb_p(0,0x71);
    outb_p(0x7E,0x70); 
    outb_p(0,0x71);
*/
/*
    outb_p(1,0x70); 
    a_sec = inb_p(0x71);
    outb_p(3,0x70); 
    a_min = inb_p(0x71);
    outb_p(5,0x70); 
    a_hour = inb_p(0x71);
    outb_p(0x7E,0x70); 
    a_7e = inb_p(0x71);
*/
/*
   asm("sti");
    iopl(0);

    hour = (hour >> 4) * 10 + (hour & 0x0f);
    min = (min >> 4) * 10 + (min & 0x0f);
    sec = (sec >> 4) * 10 + (sec & 0x0f);

    a_hour = (a_hour >> 4) * 10 + (a_hour & 0x0f);
    a_min = (a_min >> 4) * 10 + (a_min & 0x0f);
    a_sec = (a_sec >> 4) * 10 + (a_sec & 0x0f);
    a_7e = (a_7e >> 4) * 10 + (a_7e & 0x0f);
*/
/*
    printf("alarm=%d:%d:%d\n", a_hour, a_min,a_sec);
    printf("7e=%d\n", a_7e);
    printf("cmos=%d:%d:%d\n", hour, min,sec);
    printf("local=%d:%d:%d\n", pnow->tm_hour, pnow->tm_min,pnow->tm_sec);
*/
/*
    tmph = 0;
 //   tmpm = pnow->tm_min + Latency;
    tmpm = min + Latency;
     while(60 <= tmpm){
      tmpm = tmpm - 60;
      tmph++;
    }
//    tmph = tmph + pnow->tm_hour;
    tmph = tmph + hour;
    while(24 <= tmph){
      tmph = tmph - 24;
    }
    printf("%d:%d\n", tmph, tmpm);
    PonTime = tmph * 128 + tmpm * 2;
    printf("%08X\n", PonTime);

    //OpenSCI
    ghci_buf.ghci_eax = 0x0000F100;
    SCIHCI();
    printf("start %08X\n", ghci_buf.ghci_eax);
    //Set Alarm Power On Time
    ghci_buf.ghci_eax = 0x0000F400;
    ghci_buf.ghci_ebx = 0x0000010F;
    ghci_buf.ghci_ecx = PonTime;
    ghci_buf.ghci_edx = 0x00000000;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    SCIHCI();
    printf("Power On Time %08X\n", ghci_buf.ghci_eax);
    //Set Alarm Power On Date
    ghci_buf.ghci_eax = 0x0000F400;
    ghci_buf.ghci_ebx = 0x0000010E;
    ghci_buf.ghci_ecx = 0x00000000;
    ghci_buf.ghci_edx = 0x00000000;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    SCIHCI();
    printf("Power On Date %08X\n", ghci_buf.ghci_eax);


    //Set Alarm Power On Time
    ghci_buf.ghci_eax = 0x0000F300;
    ghci_buf.ghci_ebx = 0x0000010F;
    ghci_buf.ghci_ecx = 0x00000000;
    ghci_buf.ghci_edx = 0x00000000;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    SCIHCI();
    printf("[time]\n");
    printf("eax=%08X\n", ghci_buf.ghci_eax);
    printf("ebx=%08X\n", ghci_buf.ghci_ebx);
    printf("ecx=%08X\n", ghci_buf.ghci_ecx);
    printf("edx=%08X\n", ghci_buf.ghci_edx);
    printf("esi=%08X\n", ghci_buf.ghci_esi);
    printf("edi=%08X\n", ghci_buf.ghci_edi);

    //Set Alarm Power On date
    ghci_buf.ghci_eax = 0x0000F300;
    ghci_buf.ghci_ebx = 0x0000010E;
    ghci_buf.ghci_ecx = 0x00000000;
    ghci_buf.ghci_edx = 0x00000000;
    ghci_buf.ghci_esi = 0x00000000;
    ghci_buf.ghci_edi = 0x00000000;
    SCIHCI();
    printf("[date]\n");
    printf("eax=%08X\n", ghci_buf.ghci_eax);
    printf("ebx=%08X\n", ghci_buf.ghci_ebx);
    printf("ecx=%08X\n", ghci_buf.ghci_ecx);
    printf("edx=%08X\n", ghci_buf.ghci_edx);
    printf("esi=%08X\n", ghci_buf.ghci_esi);
    printf("edi=%08X\n", ghci_buf.ghci_edi);


    //CloseSCI
    ghci_buf.ghci_eax = 0x0000F200;
    SCIHCI();
    printf("close %08X\n", ghci_buf.ghci_eax);
*/
  }
  close(fd);

  return 0;
}
