$(document).ready(function() {
  $(".treeview-menu").hide(); 
	$('.nav li span').click(function()
		{
			var target_parent_li			= $(this).parent('li');
			var target_ul					= $(this).siblings('ul');
			var target_parent_sibling_li	= $(this).parent('li').siblings();
			var target_parent_sibling_li_ul	= target_parent_sibling_li.find("ul");
			
			//target_parent_sibling_li_ul.slideUp();
			if(target_ul.is(':visible'))
			{
				target_ul.slideUp();
				target_parent_li.removeClass("expanded");
			}			
			else 
			{
				target_ul.slideDown();
				target_parent_li.addClass("expanded");
			}
		});

	$('.nav > li > a, .nav > li.treeview > ul > li > a').click(function(event)
		{
			// var href = $(this).attr('href');
			// //alert(href);
			// $.ajax({
				// type: 'HEAD',
				// url: href,
				// success: function() {
					// //alert('Page found.');
					// //return true;
				// },  
				// error: function() {
					// //alert('Page not found.');
					// //secondPageValue = "<div class=\"content-iframe\"><div class=\"main-content\"><h1>&nbsp;</h1></div></div>";
					// //$('.content-iframe').html(secondPageValue);
					// //return false;
				// }
			// });
			if($(this).is('.nav > li > a')){
				$('.nav > li').removeClass('active');
				$(this).parent('li').addClass('active');
				$(this).parent('li').addClass("expanded");
				$(this).siblings('ul').slideDown();
				$('.nav > li.treeview > ul > li > a').removeClass('active-sublist');
			} else if ($(this).is('.nav > li.treeview > ul > li > a')){
				$('.nav > li').removeClass('active');
				$('.nav > li.treeview > ul > li > a').removeClass('active-sublist');
				$(this).parent('li').parent('ul').parent('li').addClass('active');
				$(this).addClass('active-sublist');
			}
		});
	
	function addAnEventListener(obj,evt,func){
		if ('addEventListener' in obj){
			obj.addEventListener(evt,func, false);
		} else if ('attachEvent' in obj){//IE
			obj.attachEvent('on'+evt,func);
		}
	}

	function iFrameListener(event){
		secondPageValue = event.data;
		$('.content-iframe').html(secondPageValue);
		$('.content-iframe').css("padding-top","45px");
		$('iframe').css("display", "none")
		$('iframe').attr("scrolling", "no")
	}
	addAnEventListener(window,'message',iFrameListener);
	$(document).on("click",".link-to-nav",function(e){
  var id = $(this).attr('href');
   $('.nav > li.treeview > ul > li > a[href*="'+id+'"]').addClass('active-sublist');
  });
  $(document).on("click",".link-to-section",function(e){
  var id = $(this).attr('href');
        e.preventDefault();
  $('html,body').animate({scrollTop: $(id).offset().top},'slow');
  });
});
