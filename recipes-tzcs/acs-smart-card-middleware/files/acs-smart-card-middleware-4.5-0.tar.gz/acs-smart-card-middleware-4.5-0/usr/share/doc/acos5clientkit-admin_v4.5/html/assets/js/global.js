$(window).load(function(){
		var browser;
		var ua = window.navigator.userAgent;
        var msie = ua.indexOf("MSIE");
        var rv = -1;
		if (msie > 0 || !!navigator.userAgent.match(/Trident.*rv\:11\./))      // If Internet Explorer, return version number
        {  
			if (isNaN(parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))))) {
                //For IE 11 >
                if (navigator.appName == 'Netscape') {
                    var ua = navigator.userAgent;
                    var re = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
                    if (re.exec(ua) != null) {
                        rv = parseFloat(RegExp.$1);
                        //alert(rv);
						//alert('te');
						browser = rv;
						var height = $('.content-iframe').html();
						parent.postMessage(height,'*');
						
                    }
                }
                else {
                    //alert('otherbrowser');
                }
            }
			else {
                //For < IE11
                //alert(parseInt(ua.substring(msie + 5, ua.indexOf(".", msie))));
				browser = parseInt(ua.substring(msie + 5, ua.indexOf(".", msie)));
            }
		}
		
		if(browser <= 9){
			//alert('less than 8');
		} else {
			//alert('not ie');
			var height = $('.content-iframe').html();
			parent.postMessage(height,'*');
		}
});
