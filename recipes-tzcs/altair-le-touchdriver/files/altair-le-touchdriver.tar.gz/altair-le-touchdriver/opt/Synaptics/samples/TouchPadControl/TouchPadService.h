//===========================================================================
// Copyright (c) 1996-2011 Synaptics Incorporated. All rights reserved.
//
// RCS Header - Do not delete or modify.
//
// $RCSfile: TouchPadService.h,v $
// $Source: /cvs/software/Driver/SynCom/TouchPadControl/TouchPadService.h,v $
//===========================================================================
#ifndef TOUCHPAD_SERVICE_H
#define TOUCHPAD_SERVICE_H

#include "SynCom.h"
#include <tr1/memory>

using namespace std::tr1;

class TouchPadService
{
public:  
  TouchPadService(shared_ptr<ISynAPI> pSynAPI);
  ~TouchPadService() {}
  LONG GetHandleToTouchPad() const;
  ISynDevice* GetTouchPad() const;

private:
  shared_ptr<ISynAPI> m_pSynAPI;
};

#endif
