//===========================================================================
// Copyright (c) 1996-2011 Synaptics Incorporated. All rights reserved.
//
// RCS Header - Do not delete or modify.
//
// $RCSfile: TouchPadControl.h,v $
// $Source: /cvs/software/Driver/SynCom/TouchPadControl/TouchPadControl.h,v $
//===========================================================================
#ifndef TOUCHPAD_CONTROL_H
#define TOUCHPAD_CONTROL_H

#include "SynCom.h"

class TouchPadControl
{
public:
  TouchPadControl(ISynDevice* pDevice);
  ~TouchPadControl();
  VOID Enable() const;
  VOID Disable() const;
  BOOL IsDisabled() const;

private:
  ISynDevice* m_pSynDevice;
};

#endif
