//===========================================================================
// Copyright (c) 1996-2011 Synaptics Incorporated. All rights reserved.
//
// RCS Header - Do not delete or modify.
//
// $RCSfile: SynComFactory.h,v $
// $Source: /cvs/software/Driver/SynCom/SynCom/SynComFactory.h,v $
//===========================================================================

#ifndef __SYN_COM_FACTORY_H_
#define __SYN_COM_FACTORY_H_

#include <tr1/memory>

class ISynAPI;

class SynComFactory
{
public:
  std::tr1::shared_ptr<ISynAPI> CreateSynAPI();
};

#endif
