/*
 * user.js file
 */

/*
 * Firefox's GUI config
 */

// disable caret browsing shortcut (F7 key)
user_pref("accessibility.browsewithcaret_shortcut.enabled", false);

// disable caret browsing feature
user_pref("accessibility.browsewithcaret", false);

// remove print dialog
user_pref("print.always_print_silent",true);
user_pref("print.show_print_progress",false);

// switch to the new tab immediately
user_pref("browser.tabs.loadInBackground", false);

// disable restore session
user_pref("browser.sessionstore.resume_from_crash", false);
user_pref("browser.sessionstore.resume_session_once", false);

// disable autohide
user_pref("browser.tabs.autoHide", false);
user_pref("browser.fullscreen.autoHide", false);

// hide tabs-closebutton
user_pref("devtools.toolbox.host", "false");

// open in new tab instead of new window
user_pref("browser.link.open_newwindow.restriction", 0);

// disable certification message 
user_pref("browser.disableResetPrompt", true);

/*
 * End of Firefox's GUI
 */
