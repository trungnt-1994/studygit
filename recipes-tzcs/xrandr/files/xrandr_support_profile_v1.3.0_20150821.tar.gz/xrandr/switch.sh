#!/bin/sh
xrandr `xrandr --profile $1`
