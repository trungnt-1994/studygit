xrandr: support profile
================================

## What's this ##

This xrandr support below profiles for display configuration.

+ Single
+ External
+ Clone
+ Exend
+ Switch

Those profiles are based on Toshiba's Fn+F5 function.

## Profiles ##

### Single ###

"Single" means Internal LCD only.

This profile is availabled always.

### External ###

"External" means External display only.

When external monitor is connected, this profile is availabled, 

### Clone ###

"Clone" means Internal LCD and External display with same image.

When external monitor is connected, this profile is availabled, 

### Extend ###

"Extend" means Internal LCD and External display with difference image.

When external monitor is connected, this profile is availabled, 

### Switch ###

"Switch" means swapping primary display and secondary display.

When now profiles is "Extend", this profile is availabled, 

## Get function ##

### Get Current Profile and Available Profiles ###

Execute xrandr without any arguments.

    > xrandr

Then you can get below strings at endpoint.

    Current Profile: extend
    Available Profile: single external clone extend switch

In this case, current profile is "Extend".
and all profiles are availabled.

Now you change display configuration to "Clone".
So you can get below.


    > xrandr
    ....
    Current Profile: clone
    Available Profile: single external clone extend

Now current profile is changed to "Clone", so "Switch" profile is hided.
Because "Switch" is availabled , when current profile is "Extend";

## Set function ##

### Basic usage ###

This xrandr has new option `--profile`.
This option generate arguments of configuration for profile.
Example try below.

    > xrandr --profile Single

Now you can get below strings.

    -output eDP1 --preferred --output HDMI1 --off

This arguments is for xrandr.
So if you want to switch to "Single" profile, please try below.

    > xrandr `xrandr --profile single`

### Single ###

    > xrandr `xrandr --profile single`

### External ###

    > xrandr `xrandr --profile external`

### Clone ###

    > xrandr `xrandr --profile clone`

### Extend ###

    > xrandr `xrandr --profile extend`

### Switch ###

    > xrandr `xrandr --profile switch`























