#ifndef __YBASE_H
#define __YBASE_H

#include "base.h"

#define __YIMP_X__

#include <X11/X.h>

#endif
