#include "config.h"
#ifdef HAVE_ASPRINTF
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#ifndef __STDC_LIMIT_MACROS
#define __STDC_LIMIT_MACROS
#endif
#include "globit.c"
#endif
