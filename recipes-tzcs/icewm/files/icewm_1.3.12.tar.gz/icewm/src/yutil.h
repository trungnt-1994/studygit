#ifndef __YUTIL_H
#define __YUTIL_H

#include "ylib.h"

#include <X11/Xutil.h>
#define __YIMP_XUTIL__

#endif
