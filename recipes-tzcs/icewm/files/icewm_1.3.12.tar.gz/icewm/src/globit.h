#ifndef GLOBIT_H
#define GLOBIT_H

#ifdef __cplusplus
extern "C" {
#endif

extern int globit_best(const char *, char **);

#ifdef __cplusplus
}
#endif

#endif /* GLOBIT_H */
